// Global variables
let recognition;
let isRecording = false;
let currentPage = window.location.pathname.split('/').pop() || 'index.html';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    initializePetSelection();
    initializeServiceCards();
});

function initializeApp() {
    // Initialize speech recognition
    initializeSpeechRecognition();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize search functionality
    initializeSearch();

    // Handle form submission response
    const form = document.querySelector('.emergency-form');
    if (form) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = getFormData();
            
            try {
                const response = await VetCareAPI.submitEmergencyRequest(formData);
                if (response.success) {
                    showNotification('Emergency request submitted successfully!', 'success');
                    resetForm();
                    // Redirect to confirmation page or show confirmation modal
                    setTimeout(() => {
                        window.location.href = 'confirmation.html';
                    }, 2000);
                } else {
                    showNotification('Submission failed. Please try again.', 'error');
                }
            } catch (error) {
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    }
    
    // Initialize page-specific functionality
    if (currentPage === 'emergency.html') {
        initializeEmergencyPage();
        initializeEmergencyInteractions();
    } else if (currentPage === 'dashboard.html') {
        initializeDashboardPage();
        initializeDashboardInteractions();
    }
}

// Speech Recognition Setup
function initializeSpeechRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';
        
        recognition.onstart = function() {
            console.log('Speech recognition started');
            isRecording = true;
            updateVoiceButton(true);
        };
        
        recognition.onresult = function(event) {
            const transcript = event.results[0][0].transcript;
            console.log('Speech recognized:', transcript);
            updateSymptomsText(transcript);
        };
        
        recognition.onerror = function(event) {
            console.error('Speech recognition error:', event.error);
            isRecording = false;
            updateVoiceButton(false);
            showNotification('Speech recognition error: ' + event.error, 'error');
        };
        
        recognition.onend = function() {
            console.log('Speech recognition ended');
            isRecording = false;
            updateVoiceButton(false);
        };
    } else {
        console.warn('Speech recognition not supported in this browser');
        // Hide voice button if not supported
        const voiceButton = document.getElementById('voiceButton');
        if (voiceButton) {
            voiceButton.style.display = 'none';
        }
    }
}

// Event Listeners Setup
function setupEventListeners() {
    // Voice button click
    const voiceButton = document.getElementById('voiceButton');
    if (voiceButton) {
        voiceButton.addEventListener('click', toggleVoiceRecording);
    }
    
    // Analyze symptoms button
    const analyzeBtn = document.getElementById('analyzeBtn');
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', analyzeSymptoms);
    }
    
    // Submit button
    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
        submitBtn.addEventListener('click', submitEmergencyRequest);
    }
    
    // Navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', handleNavigation);
    });
}

// Emergency Page Functions
function initializeEmergencyPage() {
    console.log('Initializing emergency page');
    // Additional emergency page setup if needed
}

function toggleVoiceRecording() {
    if (!recognition) {
        showNotification('Speech recognition not supported in this browser', 'error');
        return;
    }
    
    if (isRecording) {
        recognition.stop();
    } else {
        recognition.start();
    }
}

function updateVoiceButton(recording) {
    const voiceButton = document.getElementById('voiceButton');
    const voiceStatus = document.getElementById('voiceStatus');
    
    if (recording) {
        voiceButton.classList.add('recording');
        voiceButton.innerHTML = '<i class="fas fa-stop"></i>';
        voiceStatus.style.display = 'block';
    } else {
        voiceButton.classList.remove('recording');
        voiceButton.innerHTML = '<i class="fas fa-microphone"></i>';
        voiceStatus.style.display = 'none';
    }
}

function updateSymptomsText(text) {
    const symptomsTextarea = document.getElementById('symptoms');
    if (symptomsTextarea) {
        const currentText = symptomsTextarea.value;
        symptomsTextarea.value = currentText ? currentText + ' ' + text : text;
    }
}

function analyzeSymptoms() {
    const formData = getFormData();
    
    if (!validateForm(formData)) {
        return;
    }
    
    // Show loading state
    const analyzeBtn = document.getElementById('analyzeBtn');
    const originalText = analyzeBtn.innerHTML;
    analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
    analyzeBtn.disabled = true;
    
    // Simulate AI analysis (replace with actual API call)
    setTimeout(() => {
        performAIAnalysis(formData);
        analyzeBtn.innerHTML = originalText;
        analyzeBtn.disabled = false;
    }, 2000);
}

function getFormData() {
    return {
        petName: document.getElementById('petName')?.value || '',
        petType: document.getElementById('petType')?.value || '',
        petAge: document.getElementById('petAge')?.value || '',
        ownerName: document.getElementById('ownerName')?.value || '',
        phoneNumber: document.getElementById('phoneNumber')?.value || '',
        symptoms: document.getElementById('symptoms')?.value || '',
        urgency: document.getElementById('urgency')?.value || ''
    };
}

function validateForm(data) {
    const requiredFields = ['petName', 'petType', 'ownerName', 'phoneNumber', 'symptoms', 'urgency'];
    
    for (const field of requiredFields) {
        if (!data[field]) {
            showNotification(`Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()}`, 'error');
            return false;
        }
    }
    
    return true;
}

function performAIAnalysis(formData) {
    // Simulate AI analysis results
    const analysisResults = {
        possibleConditions: [
            'Respiratory distress',
            'Cardiac condition',
            'Allergic reaction'
        ],
        recommendedVet: {
            name: 'Dr. Sarah Johnson',
            specialty: 'Emergency Medicine',
            experience: '8 years',
            availability: 'Available now'
        },
        waitTime: '5-10 minutes',
        nextSteps: [
            'Bring your pet to the emergency room immediately',
            'Keep your pet calm and comfortable',
            'Monitor breathing and heart rate',
            'Avoid giving food or water until examined'
        ],
        confidence: '92%'
    };
    
    displayAnalysisResults(analysisResults);
    showNotification('AI analysis completed successfully!', 'success');
}

function displayAnalysisResults(results) {
    const analysisResults = document.getElementById('analysisResults');
    const possibleConditions = document.getElementById('possibleConditions');
    const recommendedVet = document.getElementById('recommendedVet');
    const waitTime = document.getElementById('waitTime');
    const nextSteps = document.getElementById('nextSteps');
    const submitBtn = document.getElementById('submitBtn');
    
    // Show analysis results
    analysisResults.style.display = 'block';
    
    // Populate possible conditions
    possibleConditions.innerHTML = results.possibleConditions
        .map(condition => `<li>${condition}</li>`)
        .join('');
    
    // Populate recommended vet
    recommendedVet.innerHTML = `
        <div class="vet-details">
            <h5>${results.recommendedVet.name}</h5>
            <p><strong>Specialty:</strong> ${results.recommendedVet.specialty}</p>
            <p><strong>Experience:</strong> ${results.recommendedVet.experience}</p>
            <p><strong>Status:</strong> <span class="status-available">${results.recommendedVet.availability}</span></p>
        </div>
    `;
    
    // Populate wait time
    waitTime.innerHTML = `<span class="wait-time">${results.waitTime}</span>`;
    
    // Populate next steps
    nextSteps.innerHTML = results.nextSteps
        .map(step => `<p>• ${step}</p>`)
        .join('');
    
    // Show submit button
    submitBtn.style.display = 'inline-flex';
    
    // Scroll to results
    analysisResults.scrollIntoView({ behavior: 'smooth' });
}

function submitEmergencyRequest() {
    const formData = getFormData();
    
    // Show loading state
    const submitBtn = document.getElementById('submitBtn');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    submitBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // Simulate successful submission
        showNotification('Emergency request submitted successfully! You will be contacted shortly.', 'success');
        
        // Reset form
        resetForm();
        
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        submitBtn.style.display = 'none';
        
        // Hide analysis results
        document.getElementById('analysisResults').style.display = 'none';
        
    }, 1500);
}

function resetForm() {
    const form = document.querySelector('.emergency-form');
    if (form) {
        form.reset();
    }
}

// Dashboard Page Functions
function initializeDashboardPage() {
    console.log('Initializing dashboard page');
    // Dashboard-specific initialization is handled in dashboard.html
}

// Navigation Functions
function goToEmergency() {
    window.location.href = 'emergency.html';
}

function goToDashboard() {
    window.location.href = 'dashboard.html';
}

function handleNavigation(event) {
    event.preventDefault();
    const href = event.target.getAttribute('href');
    
    if (href && href !== '#') {
        if (href.startsWith('#')) {
            // Handle anchor links
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        } else {
            // Handle page navigation
            window.location.href = href;
        }
    }
}

// Utility Functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 10px;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

function getNotificationColor(type) {
    const colors = {
        success: '#27ae60',
        error: '#e74c3c',
        warning: '#f39c12',
        info: '#3498db'
    };
    return colors[type] || '#3498db';
}

// Add CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// API Integration Functions (to be implemented with actual backend)
class VetCareAPI {
    static baseURL = 'http://localhost:8000/api'; // Django backend URL
    
    static async analyzeSymptoms(symptoms, petType, urgency) {
        try {
            const response = await fetch(`${this.baseURL}/analyze-symptoms/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    symptoms,
                    pet_type: petType,
                    urgency_level: urgency
                })
            });
            
            if (!response.ok) {
                throw new Error('Analysis failed');
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            // Fallback to simulated analysis
            return this.getSimulatedAnalysis(symptoms, petType, urgency);
        }
    }
    
    static async submitEmergencyRequest(formData) {
        try {
            const response = await fetch(`${this.baseURL}/emergency-requests/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            if (!response.ok) {
                throw new Error('Submission failed');
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            // Fallback to simulated success
            return { success: true, message: 'Request submitted successfully' };
        }
    }
    
    static async getDashboardData() {
        try {
            const response = await fetch(`${this.baseURL}/dashboard/`);
            
            if (!response.ok) {
                throw new Error('Failed to fetch dashboard data');
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            // Return simulated data
            return this.getSimulatedDashboardData();
        }
    }
    
    static getSimulatedAnalysis(symptoms, petType, urgency) {
        // This would be replaced with actual AI analysis
        return {
            possible_conditions: ['Respiratory distress', 'Cardiac condition'],
            recommended_vet: {
                name: 'Dr. Sarah Johnson',
                specialty: 'Emergency Medicine',
                experience: '8 years',
                availability: 'Available now'
            },
            wait_time: '5-10 minutes',
            next_steps: [
                'Bring your pet to the emergency room immediately',
                'Keep your pet calm and comfortable'
            ],
            confidence: '92%'
        };
    }
    
    static getSimulatedDashboardData() {
        return {
            active_emergencies: Math.floor(Math.random() * 10),
            available_vets: Math.floor(Math.random() * 8) + 2,
            avg_wait_time: Math.floor(Math.random() * 30) + 5,
            partner_hospitals: 3,
            current_cases: [],
            veterinarians: [],
            ai_decisions: []
        };
    }
}

// Pet Selection Functions
function initializePetSelection() {
    const petOptions = document.querySelectorAll('.pet-option');
    const carouselBtn = document.querySelector('.carousel-btn');
    
    petOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            petOptions.forEach(opt => opt.classList.remove('active'));
            // Add active class to clicked option
            this.classList.add('active');
        });
    });
    
    if (carouselBtn) {
        carouselBtn.addEventListener('click', function() {
            // Simple carousel functionality
            const petOptionsContainer = document.querySelector('.pet-options');
            petOptionsContainer.scrollBy({ left: 100, behavior: 'smooth' });
        });
    }
}

// Service Cards Functions
function initializeServiceCards() {
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add click animation
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
            
            // Handle different service clicks
            const serviceType = this.classList[1]; // boarding, veterinary, etc.
            handleServiceClick(serviceType);
        });
    });
}

function handleServiceClick(serviceType) {
    switch(serviceType) {
        case 'boarding':
            showNotification('Boarding service selected! Redirecting to booking...', 'info');
            break;
        case 'veterinary':
            showNotification('Veterinary service selected! Opening consultation...', 'info');
            break;
        case 'live-video':
            showNotification('Live video service selected! Starting video feed...', 'info');
            break;
        case 'training':
            showNotification('Training service selected! Connecting with trainers...', 'info');
            break;
        case 'grooming':
            showNotification('Grooming service selected! Booking appointment...', 'info');
            break;
        default:
            showNotification('Service selected!', 'info');
    }
}

// Search functionality
function initializeSearch() {
    const searchBtn = document.querySelector('.search-btn');
    const searchInputs = document.querySelectorAll('.search-input');
    
    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            const dropOff = searchInputs[0].value;
            const pickUp = searchInputs[1].value;
            
            if (!dropOff || !pickUp) {
                showNotification('Please fill in both drop off and pick up dates', 'warning');
                return;
            }
            
            showNotification(`Searching for services from ${dropOff} to ${pickUp}...`, 'info');
            // Here you would implement actual search functionality
        });
    }
}

// Export functions for global access
window.goToEmergency = goToEmergency;
window.goToDashboard = goToDashboard;
window.refreshCases = function() {
    if (typeof loadCases === 'function') {
        loadCases();
    }
};
