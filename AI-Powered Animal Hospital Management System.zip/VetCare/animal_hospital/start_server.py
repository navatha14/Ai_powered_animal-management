#!/usr/bin/env python3
"""
Start script for AI-Powered Animal Hospital Management System
"""

import os
import sys
import subprocess
import platform
import webbrowser
import time
from pathlib import Path

def run_command(command, cwd=None):
    """Run a command and return the result"""
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            cwd=cwd, 
            capture_output=True, 
            text=True, 
            check=True
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def start_django_server():
    """Start the Django development server"""
    print("🚀 Starting Django server...")
    
    # Determine python command based on OS
    if platform.system() == "Windows":
        python_cmd = "backend\\venv\\Scripts\\python"
    else:
        python_cmd = "backend/venv/bin/python"
    
    # Start Django server
    try:
        subprocess.Popen(
            [python_cmd, "manage.py", "runserver"],
            cwd="backend"
        )
        print("✅ Django server started on http://localhost:8000")
        return True
    except Exception as e:
        print(f"❌ Failed to start Django server: {e}")
        return False

def open_frontend():
    """Open the frontend in the default browser"""
    print("🌐 Opening frontend...")
    
    frontend_path = Path("frontend/index.html").resolve()
    
    if not frontend_path.exists():
        print("❌ Frontend file not found")
        return False
    
    try:
        webbrowser.open(f"file://{frontend_path}")
        print("✅ Frontend opened in browser")
        return True
    except Exception as e:
        print(f"❌ Failed to open frontend: {e}")
        return False

def main():
    """Main start function"""
    print("🏥 AI-Powered Animal Hospital Management System")
    print("=" * 50)
    
    # Check if virtual environment exists
    venv_path = Path("backend/venv")
    if not venv_path.exists():
        print("❌ Virtual environment not found. Please run setup.py first.")
        sys.exit(1)
    
    # Check if Django is installed
    if platform.system() == "Windows":
        python_cmd = "backend\\venv\\Scripts\\python"
    else:
        python_cmd = "backend/venv/bin/python"
    
    success, _ = run_command(f"{python_cmd} -c \"import django\"", cwd="backend")
    if not success:
        print("❌ Django not found. Please run setup.py first.")
        sys.exit(1)
    
    # Start Django server
    if not start_django_server():
        sys.exit(1)
    
    # Wait a moment for server to start
    print("⏳ Waiting for server to start...")
    time.sleep(3)
    
    # Open frontend
    open_frontend()
    
    print("\n🎉 System is running!")
    print("\nAccess points:")
    print("• Frontend: frontend/index.html")
    print("• Backend API: http://localhost:8000/api/")
    print("• Admin Interface: http://localhost:8000/admin/")
    print("• Dashboard: frontend/dashboard.html")
    print("• Emergency Form: frontend/emergency.html")
    
    print("\nPress Ctrl+C to stop the server")
    
    try:
        # Keep the script running
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n👋 Shutting down...")
        sys.exit(0)

if __name__ == "__main__":
    main()
