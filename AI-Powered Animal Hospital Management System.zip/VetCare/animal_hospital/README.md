# AI-Powered Animal Hospital Management System

A comprehensive system that automates emergency and routine consultations for animal hospitals using AI-powered symptom analysis and intelligent veterinarian assignment.

## Features

### 🤖 AI-Powered Analysis
- **Speech-to-Text**: Convert spoken symptom descriptions to text
- **Natural Language Processing**: Analyze symptoms using advanced NLP
- **Intelligent Triage**: Automatically assess urgency and assign appropriate care
- **Condition Prediction**: Identify possible medical conditions based on symptoms

### 🏥 Hospital Management
- **Real-time Dashboard**: Monitor active cases, available vets, and system metrics
- **Veterinarian Assignment**: Automatically assign the most suitable vet based on specialty and availability
- **Partner Hospital Routing**: Route cases to nearby partner hospitals when no local vets are available
- **Emergency Tracking**: Track emergency requests from creation to completion

### 📱 Modern Web Interface
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Real-time Updates**: Live dashboard with automatic refresh
- **Voice Input**: Record symptoms using speech-to-text technology
- **Intuitive UI**: Clean, modern interface with excellent UX

## Technology Stack

### Frontend
- **HTML5/CSS3**: Modern, responsive web interface
- **JavaScript**: Interactive features and API integration
- **Speech Recognition API**: Browser-based voice input
- **Chart.js**: Data visualization for dashboard

### Backend
- **Django 4.2**: Python web framework
- **Django REST Framework**: API development
- **SQLite/PostgreSQL**: Database (SQLite for development, PostgreSQL for production)
- **OpenAI API**: Advanced AI analysis (optional)
- **Celery**: Background task processing

### AI/ML
- **Natural Language Processing**: Symptom analysis and condition prediction
- **Machine Learning**: Pattern recognition and decision making
- **Rule-based Fallback**: Reliable analysis when AI services are unavailable

## Project Structure

```
animal_hospital/
├── frontend/                 # Frontend web interface
│   ├── index.html           # Landing page
│   ├── dashboard.html       # Hospital dashboard
│   ├── emergency.html       # Emergency request form
│   ├── css/
│   │   └── style.css        # Styling
│   └── js/
│       └── app.js           # JavaScript functionality
├── backend/                 # Django backend
│   ├── animal_hospital/     # Django project settings
│   ├── hospital/            # Main application
│   │   ├── models.py        # Database models
│   │   ├── views.py         # API views
│   │   ├── serializers.py   # Data serialization
│   │   ├── ai_service.py    # AI/NLP logic
│   │   ├── admin.py         # Admin interface
│   │   └── urls.py          # URL routing
│   ├── manage.py            # Django management
│   └── requirements.txt     # Python dependencies
└── README.md               # This file
```

## Quick Start

### Prerequisites
- Python 3.8 or higher
- Node.js (for frontend development, optional)
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd animal_hospital
   ```

2. **Set up the backend**
   ```bash
   cd backend
   
   # Create virtual environment
   python -m venv venv
   
   # Activate virtual environment
   # On Windows:
   venv\Scripts\activate
   # On macOS/Linux:
   source venv/bin/activate
   
   # Install dependencies
   pip install -r requirements.txt
   
   # Run migrations
   python manage.py migrate
   
   # Create superuser (optional)
   python manage.py createsuperuser
   
   # Populate with sample data
   python manage.py populate_sample_data
   
   # Start the development server
   python manage.py runserver
   ```

3. **Access the application**
   - Backend API: http://localhost:8000/api/
   - Admin Interface: http://localhost:8000/admin/
   - Frontend: Open `frontend/index.html` in your browser

### Environment Variables

Create a `.env` file in the `backend` directory:

```env
# Django Settings
SECRET_KEY=your-secret-key-here
DEBUG=True

# Database (for production)
DB_NAME=animal_hospital
DB_USER=postgres
DB_PASSWORD=your-password
DB_HOST=localhost
DB_PORT=5432

# AI Services (optional)
OPENAI_API_KEY=your-openai-api-key

# Celery (for background tasks)
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
```

## API Endpoints

### Emergency Requests
- `POST /api/emergency-requests/` - Create new emergency request
- `GET /api/emergency-requests/list/` - List emergency requests
- `GET /api/emergency-requests/{id}/` - Get specific emergency request
- `POST /api/emergency-requests/{id}/update-status/` - Update request status

### Symptom Analysis
- `POST /api/analyze-symptoms/` - Analyze symptoms using AI

### Dashboard
- `GET /api/dashboard/` - Get dashboard data
- `GET /api/veterinarians/` - List veterinarians
- `GET /api/partner-hospitals/` - List partner hospitals

### System Metrics
- `GET /api/metrics/` - Get system performance metrics
- `POST /api/metrics/create/` - Create/update metrics

## Usage Examples

### Creating an Emergency Request

```javascript
// Using the frontend form
const formData = {
    pet_name: "Buddy",
    pet_type: "dog",
    pet_age: 5,
    owner_name: "John Smith",
    phone_number: "+1-555-0123",
    symptoms: "Difficulty breathing, pale gums, lethargy",
    urgency: "critical"
};

// The system will automatically:
// 1. Analyze symptoms using AI
// 2. Assign appropriate veterinarian
// 3. Route to partner hospital if needed
// 4. Provide estimated wait time
```

### Analyzing Symptoms

```javascript
// Direct API call
const response = await fetch('/api/analyze-symptoms/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        symptoms: "Vomiting, not eating, hiding",
        pet_type: "cat",
        urgency_level: "urgent"
    })
});

const analysis = await response.json();
// Returns: possible_conditions, confidence_score, recommendations, etc.
```

## AI Features

### Symptom Analysis
The AI service analyzes pet symptoms using:
- **Keyword matching** for common conditions
- **OpenAI GPT integration** for advanced analysis (optional)
- **Rule-based fallback** for reliable operation
- **Confidence scoring** for decision quality

### Veterinarian Assignment
Intelligent assignment based on:
- **Specialty matching** (emergency, surgery, cardiology, etc.)
- **Availability status** (available, busy, on break)
- **Experience level** and expertise
- **Current workload**

### Partner Hospital Routing
When no local vets are available:
- **Distance-based selection** (closest hospitals first)
- **Specialty matching** (hospitals with relevant expertise)
- **Availability checking** (vets and wait times)
- **Automatic routing** with seamless handoff

## Development

### Running Tests
```bash
cd backend
python manage.py test
```

### Database Management
```bash
# Create migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Reset database (development only)
python manage.py flush
```

### Adding New Features
1. Create models in `hospital/models.py`
2. Add serializers in `hospital/serializers.py`
3. Create views in `hospital/views.py`
4. Update URLs in `hospital/urls.py`
5. Add frontend integration in `frontend/js/app.js`

## Deployment

### Production Setup
1. Set `DEBUG=False` in settings
2. Configure PostgreSQL database
3. Set up Redis for Celery
4. Configure static file serving
5. Set up SSL certificates
6. Configure environment variables

### Docker Deployment
```bash
# Build and run with Docker Compose
docker-compose up -d
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation

## Roadmap

### Upcoming Features
- [ ] Mobile app (React Native)
- [ ] Real-time notifications
- [ ] Advanced ML models
- [ ] Multi-language support
- [ ] Integration with veterinary databases
- [ ] Telemedicine capabilities
- [ ] Automated follow-up system

### Performance Improvements
- [ ] Caching layer
- [ ] Database optimization
- [ ] API rate limiting
- [ ] Background task optimization
- [ ] Real-time data streaming

---

**Built with ❤️ for better animal healthcare**
