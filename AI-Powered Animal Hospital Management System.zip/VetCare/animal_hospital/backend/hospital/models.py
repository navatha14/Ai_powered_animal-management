from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid


class Veterinarian(models.Model):
    """Model representing a veterinarian"""
    
    SPECIALTY_CHOICES = [
        ('emergency', 'Emergency Medicine'),
        ('surgery', 'Surgery'),
        ('internal', 'Internal Medicine'),
        ('cardiology', 'Cardiology'),
        ('oncology', 'Oncology'),
        ('dermatology', 'Dermatology'),
        ('neurology', 'Neurology'),
        ('orthopedics', 'Orthopedics'),
        ('general', 'General Practice'),
    ]
    
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('busy', 'Busy'),
        ('on_break', 'On Break'),
        ('off_duty', 'Off Duty'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    license_number = models.CharField(max_length=50, unique=True)
    specialty = models.CharField(max_length=20, choices=SPECIALTY_CHOICES)
    experience_years = models.PositiveIntegerField(default=0)
    phone_number = models.CharField(max_length=20)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    current_case = models.ForeignKey('EmergencyRequest', on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Dr. {self.user.get_full_name() or self.user.username}"
    
    class Meta:
        ordering = ['-created_at']


class PartnerHospital(models.Model):
    """Model representing partner hospitals"""
    
    name = models.CharField(max_length=200)
    address = models.TextField()
    phone_number = models.CharField(max_length=20)
    email = models.EmailField()
    distance_miles = models.FloatField()
    available_vets = models.PositiveIntegerField(default=0)
    wait_time_minutes = models.PositiveIntegerField(default=0)
    specialties = models.JSONField(default=list)  # List of specialties available
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.name
    
    class Meta:
        ordering = ['distance_miles']


class EmergencyRequest(models.Model):
    """Model representing an emergency request"""
    
    URGENCY_CHOICES = [
        ('critical', 'Critical - Life threatening'),
        ('urgent', 'Urgent - Needs immediate attention'),
        ('moderate', 'Moderate - Can wait a few hours'),
        ('routine', 'Routine - Non-emergency'),
    ]
    
    PET_TYPE_CHOICES = [
        ('dog', 'Dog'),
        ('cat', 'Cat'),
        ('bird', 'Bird'),
        ('rabbit', 'Rabbit'),
        ('hamster', 'Hamster'),
        ('guinea_pig', 'Guinea Pig'),
        ('other', 'Other'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending Analysis'),
        ('analyzed', 'Analyzed'),
        ('assigned', 'Assigned to Vet'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    pet_name = models.CharField(max_length=100)
    pet_type = models.CharField(max_length=20, choices=PET_TYPE_CHOICES)
    pet_age = models.PositiveIntegerField(null=True, blank=True)
    owner_name = models.CharField(max_length=200)
    phone_number = models.CharField(max_length=20)
    symptoms = models.TextField()
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # AI Analysis Results
    possible_conditions = models.JSONField(default=list)
    confidence_score = models.FloatField(null=True, blank=True)
    ai_recommendations = models.TextField(blank=True)
    
    # Assignment
    assigned_veterinarian = models.ForeignKey(
        Veterinarian, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True
    )
    partner_hospital = models.ForeignKey(
        PartnerHospital, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True
    )
    
    # Timing
    estimated_wait_time = models.PositiveIntegerField(null=True, blank=True)  # in minutes
    created_at = models.DateTimeField(auto_now_add=True)
    analyzed_at = models.DateTimeField(null=True, blank=True)
    assigned_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"Emergency Request for {self.pet_name} - {self.get_urgency_display()}"
    
    class Meta:
        ordering = ['-created_at']


class AIDecision(models.Model):
    """Model to track AI decisions and their outcomes"""
    
    emergency_request = models.ForeignKey(EmergencyRequest, on_delete=models.CASCADE)
    decision_type = models.CharField(max_length=50)  # e.g., 'vet_assignment', 'condition_analysis'
    input_data = models.JSONField()  # Input data used for decision
    output_data = models.JSONField()  # AI output/decision
    confidence_score = models.FloatField()
    processing_time = models.FloatField()  # Time taken for AI processing in seconds
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"AI Decision for {self.emergency_request.pet_name} - {self.decision_type}"
    
    class Meta:
        ordering = ['-created_at']


class SymptomPattern(models.Model):
    """Model to store learned symptom patterns for ML"""
    
    symptoms = models.TextField()
    conditions = models.JSONField()  # List of possible conditions
    pet_type = models.CharField(max_length=20)
    urgency_level = models.CharField(max_length=20)
    frequency = models.PositiveIntegerField(default=1)  # How often this pattern occurs
    accuracy_score = models.FloatField(default=0.0)  # Accuracy of this pattern
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Symptom Pattern: {self.symptoms[:50]}..."
    
    class Meta:
        ordering = ['-frequency', '-accuracy_score']


class SystemMetrics(models.Model):
    """Model to track system performance metrics"""
    
    date = models.DateField(unique=True)
    total_requests = models.PositiveIntegerField(default=0)
    successful_assignments = models.PositiveIntegerField(default=0)
    ai_accuracy = models.FloatField(default=0.0)
    avg_response_time = models.FloatField(default=0.0)  # in seconds
    avg_wait_time = models.FloatField(default=0.0)  # in minutes
    partner_hospital_usage = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Metrics for {self.date}"
    
    class Meta:
        ordering = ['-date']
