from django.contrib import admin
from .models import (
    Veterinarian, PartnerHospital, EmergencyRequest, 
    AIDecision, SymptomPattern, SystemMetrics
)


@admin.register(Veterinarian)
class VeterinarianAdmin(admin.ModelAdmin):
    list_display = ['user', 'license_number', 'specialty', 'status', 'experience_years', 'created_at']
    list_filter = ['specialty', 'status', 'created_at']
    search_fields = ['user__username', 'user__first_name', 'user__last_name', 'license_number']
    ordering = ['-created_at']


@admin.register(PartnerHospital)
class PartnerHospitalAdmin(admin.ModelAdmin):
    list_display = ['name', 'distance_miles', 'available_vets', 'wait_time_minutes', 'is_active']
    list_filter = ['is_active', 'specialties']
    search_fields = ['name', 'address']
    ordering = ['distance_miles']


@admin.register(EmergencyRequest)
class EmergencyRequestAdmin(admin.ModelAdmin):
    list_display = [
        'pet_name', 'pet_type', 'urgency', 'status', 
        'assigned_veterinarian', 'created_at'
    ]
    list_filter = ['urgency', 'status', 'pet_type', 'created_at']
    search_fields = ['pet_name', 'owner_name', 'phone_number']
    readonly_fields = ['id', 'created_at', 'analyzed_at', 'assigned_at', 'completed_at']
    ordering = ['-created_at']
    
    fieldsets = (
        ('Pet Information', {
            'fields': ('pet_name', 'pet_type', 'pet_age')
        }),
        ('Owner Information', {
            'fields': ('owner_name', 'phone_number')
        }),
        ('Emergency Details', {
            'fields': ('symptoms', 'urgency', 'status')
        }),
        ('AI Analysis', {
            'fields': ('possible_conditions', 'confidence_score', 'ai_recommendations')
        }),
        ('Assignment', {
            'fields': ('assigned_veterinarian', 'partner_hospital', 'estimated_wait_time')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'analyzed_at', 'assigned_at', 'completed_at'),
            'classes': ('collapse',)
        })
    )


@admin.register(AIDecision)
class AIDecisionAdmin(admin.ModelAdmin):
    list_display = [
        'emergency_request', 'decision_type', 'confidence_score', 
        'processing_time', 'created_at'
    ]
    list_filter = ['decision_type', 'created_at']
    search_fields = ['emergency_request__pet_name']
    readonly_fields = ['created_at']
    ordering = ['-created_at']


@admin.register(SymptomPattern)
class SymptomPatternAdmin(admin.ModelAdmin):
    list_display = [
        'symptoms_short', 'pet_type', 'urgency_level', 
        'frequency', 'accuracy_score', 'created_at'
    ]
    list_filter = ['pet_type', 'urgency_level', 'created_at']
    search_fields = ['symptoms']
    ordering = ['-frequency', '-accuracy_score']
    
    def symptoms_short(self, obj):
        return obj.symptoms[:50] + '...' if len(obj.symptoms) > 50 else obj.symptoms
    symptoms_short.short_description = 'Symptoms'


@admin.register(SystemMetrics)
class SystemMetricsAdmin(admin.ModelAdmin):
    list_display = [
        'date', 'total_requests', 'successful_assignments', 
        'ai_accuracy', 'avg_response_time', 'avg_wait_time'
    ]
    list_filter = ['date']
    ordering = ['-date']
    readonly_fields = ['created_at']
