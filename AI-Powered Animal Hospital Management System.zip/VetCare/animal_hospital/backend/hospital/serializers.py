from rest_framework import serializers
from .models import Veterinarian, PartnerHospital, EmergencyRequest, AIDecision, SymptomPattern, SystemMetrics


class VeterinarianSerializer(serializers.ModelSerializer):
    """Serializer for Veterinarian model"""
    
    full_name = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    specialty_display = serializers.CharField(source='get_specialty_display', read_only=True)
    
    class Meta:
        model = Veterinarian
        fields = [
            'id', 'user', 'license_number', 'specialty', 'specialty_display',
            'experience_years', 'phone_number', 'status', 'status_display',
            'current_case', 'full_name', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_full_name(self, obj):
        return obj.user.get_full_name() or obj.user.username


class PartnerHospitalSerializer(serializers.ModelSerializer):
    """Serializer for PartnerHospital model"""
    
    class Meta:
        model = PartnerHospital
        fields = [
            'id', 'name', 'address', 'phone_number', 'email',
            'distance_miles', 'available_vets', 'wait_time_minutes',
            'specialties', 'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class EmergencyRequestSerializer(serializers.ModelSerializer):
    """Serializer for EmergencyRequest model"""
    
    urgency_display = serializers.CharField(source='get_urgency_display', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    pet_type_display = serializers.CharField(source='get_pet_type_display', read_only=True)
    assigned_veterinarian_name = serializers.SerializerMethodField()
    partner_hospital_name = serializers.SerializerMethodField()
    
    class Meta:
        model = EmergencyRequest
        fields = [
            'id', 'pet_name', 'pet_type', 'pet_type_display', 'pet_age',
            'owner_name', 'phone_number', 'symptoms', 'urgency', 'urgency_display',
            'status', 'status_display', 'possible_conditions', 'confidence_score',
            'ai_recommendations', 'assigned_veterinarian', 'assigned_veterinarian_name',
            'partner_hospital', 'partner_hospital_name', 'estimated_wait_time',
            'created_at', 'analyzed_at', 'assigned_at', 'completed_at'
        ]
        read_only_fields = [
            'id', 'created_at', 'analyzed_at', 'assigned_at', 'completed_at',
            'possible_conditions', 'confidence_score', 'ai_recommendations'
        ]
    
    def get_assigned_veterinarian_name(self, obj):
        if obj.assigned_veterinarian:
            return str(obj.assigned_veterinarian)
        return None
    
    def get_partner_hospital_name(self, obj):
        if obj.partner_hospital:
            return obj.partner_hospital.name
        return None


class EmergencyRequestCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating EmergencyRequest"""
    
    class Meta:
        model = EmergencyRequest
        fields = [
            'pet_name', 'pet_type', 'pet_age', 'owner_name',
            'phone_number', 'symptoms', 'urgency'
        ]


class AIDecisionSerializer(serializers.ModelSerializer):
    """Serializer for AIDecision model"""
    
    emergency_request_pet_name = serializers.CharField(source='emergency_request.pet_name', read_only=True)
    
    class Meta:
        model = AIDecision
        fields = [
            'id', 'emergency_request', 'emergency_request_pet_name',
            'decision_type', 'input_data', 'output_data', 'confidence_score',
            'processing_time', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class SymptomPatternSerializer(serializers.ModelSerializer):
    """Serializer for SymptomPattern model"""
    
    class Meta:
        model = SymptomPattern
        fields = [
            'id', 'symptoms', 'conditions', 'pet_type', 'urgency_level',
            'frequency', 'accuracy_score', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class SystemMetricsSerializer(serializers.ModelSerializer):
    """Serializer for SystemMetrics model"""
    
    class Meta:
        model = SystemMetrics
        fields = [
            'id', 'date', 'total_requests', 'successful_assignments',
            'ai_accuracy', 'avg_response_time', 'avg_wait_time',
            'partner_hospital_usage', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class DashboardDataSerializer(serializers.Serializer):
    """Serializer for dashboard data aggregation"""
    
    active_emergencies = serializers.IntegerField()
    available_vets = serializers.IntegerField()
    avg_wait_time = serializers.FloatField()
    partner_hospitals = serializers.IntegerField()
    current_cases = EmergencyRequestSerializer(many=True)
    veterinarians = VeterinarianSerializer(many=True)
    partner_hospitals_list = PartnerHospitalSerializer(many=True)
    ai_decisions = AIDecisionSerializer(many=True)
    recent_metrics = SystemMetricsSerializer(many=True)


class SymptomAnalysisRequestSerializer(serializers.Serializer):
    """Serializer for symptom analysis requests"""
    
    symptoms = serializers.CharField(max_length=2000)
    pet_type = serializers.CharField(max_length=20)
    urgency_level = serializers.CharField(max_length=20)
    pet_age = serializers.IntegerField(required=False, allow_null=True)


class SymptomAnalysisResponseSerializer(serializers.Serializer):
    """Serializer for symptom analysis responses"""
    
    possible_conditions = serializers.ListField(child=serializers.CharField())
    confidence_score = serializers.FloatField()
    recommended_vet_specialty = serializers.CharField()
    urgency_assessment = serializers.CharField()
    next_steps = serializers.ListField(child=serializers.CharField())
    estimated_wait_time = serializers.IntegerField()
