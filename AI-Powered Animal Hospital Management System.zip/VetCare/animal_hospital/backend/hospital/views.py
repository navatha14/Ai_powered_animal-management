"""
Views for Animal Hospital Management System

This module handles all API endpoints for:
- Emergency requests
- Symptom analysis
- Veterinarian management
- Dashboard data
- AI operations
"""

from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db.models import Q, Count, Avg
from datetime import datetime, timedelta
import logging

from .models import (
    Veterinarian, PartnerHospital, EmergencyRequest, 
    AIDecision, SymptomPattern, SystemMetrics
)
from .serializers import (
    VeterinarianSerializer, PartnerHospitalSerializer, EmergencyRequestSerializer,
    EmergencyRequestCreateSerializer, AIDecisionSerializer, SymptomPatternSerializer,
    SystemMetricsSerializer, DashboardDataSerializer, SymptomAnalysisRequestSerializer,
    SymptomAnalysisResponseSerializer
)
from .ai_service import ai_service

logger = logging.getLogger(__name__)


@api_view(['POST'])
@permission_classes([AllowAny])
def analyze_symptoms(request):
    """
    Analyze pet symptoms using AI
    
    POST /api/analyze-symptoms/
    """
    try:
        serializer = SymptomAnalysisRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        symptoms = data['symptoms']
        pet_type = data['pet_type']
        urgency_level = data['urgency_level']
        pet_age = data.get('pet_age')
        
        # Perform AI analysis
        analysis_result = ai_service.analyze_symptoms(
            symptoms=symptoms,
            pet_type=pet_type,
            urgency_level=urgency_level,
            pet_age=pet_age
        )
        
        # Return analysis results
        response_serializer = SymptomAnalysisResponseSerializer(data=analysis_result)
        if response_serializer.is_valid():
            return Response(response_serializer.validated_data, status=status.HTTP_200_OK)
        else:
            return Response(analysis_result, status=status.HTTP_200_OK)
            
    except Exception as e:
        logger.error(f"Error in symptom analysis: {str(e)}")
        return Response(
            {'error': 'Analysis failed. Please try again.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([AllowAny])
def create_emergency_request(request):
    """
    Create a new emergency request
    
    POST /api/emergency-requests/
    """
    try:
        serializer = EmergencyRequestCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        # Create emergency request
        emergency_request = serializer.save()
        
        # Perform AI analysis
        analysis_result = ai_service.analyze_symptoms(
            symptoms=emergency_request.symptoms,
            pet_type=emergency_request.pet_type,
            urgency_level=emergency_request.urgency,
            pet_age=emergency_request.pet_age
        )
        
        # Update emergency request with AI analysis
        emergency_request.possible_conditions = analysis_result.get('possible_conditions', [])
        emergency_request.confidence_score = analysis_result.get('confidence_score', 0.0)
        emergency_request.ai_recommendations = '\n'.join(analysis_result.get('next_steps', []))
        emergency_request.status = 'analyzed'
        emergency_request.analyzed_at = timezone.now()
        emergency_request.estimated_wait_time = analysis_result.get('estimated_wait_time', 60)
        emergency_request.save()
        
        # Try to assign veterinarian
        assigned_vet = ai_service.assign_veterinarian(emergency_request)
        if assigned_vet:
            emergency_request.assigned_veterinarian = assigned_vet
            emergency_request.status = 'assigned'
            emergency_request.assigned_at = timezone.now()
            assigned_vet.current_case = emergency_request
            assigned_vet.status = 'busy'
            assigned_vet.save()
        else:
            # Try to find partner hospital
            partner_hospital = ai_service.find_partner_hospital(emergency_request)
            if partner_hospital:
                emergency_request.partner_hospital = partner_hospital
                emergency_request.status = 'assigned'
                emergency_request.assigned_at = timezone.now()
        
        emergency_request.save()
        
        # Return created emergency request
        response_serializer = EmergencyRequestSerializer(emergency_request)
        return Response(response_serializer.data, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        logger.error(f"Error creating emergency request: {str(e)}")
        return Response(
            {'error': 'Failed to create emergency request. Please try again.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_emergency_requests(request):
    """
    Get list of emergency requests
    
    GET /api/emergency-requests/
    """
    try:
        # Get query parameters
        status_filter = request.GET.get('status')
        urgency_filter = request.GET.get('urgency')
        limit = int(request.GET.get('limit', 20))
        
        # Build query
        queryset = EmergencyRequest.objects.all()
        
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        if urgency_filter:
            queryset = queryset.filter(urgency=urgency_filter)
        
        # Order by creation date (newest first)
        queryset = queryset.order_by('-created_at')[:limit]
        
        serializer = EmergencyRequestSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching emergency requests: {str(e)}")
        return Response(
            {'error': 'Failed to fetch emergency requests.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_emergency_request(request, request_id):
    """
    Get specific emergency request by ID
    
    GET /api/emergency-requests/{id}/
    """
    try:
        emergency_request = get_object_or_404(EmergencyRequest, id=request_id)
        serializer = EmergencyRequestSerializer(emergency_request)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching emergency request {request_id}: {str(e)}")
        return Response(
            {'error': 'Emergency request not found.'}, 
            status=status.HTTP_404_NOT_FOUND
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_veterinarians(request):
    """
    Get list of veterinarians
    
    GET /api/veterinarians/
    """
    try:
        status_filter = request.GET.get('status')
        
        queryset = Veterinarian.objects.all()
        
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        
        serializer = VeterinarianSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching veterinarians: {str(e)}")
        return Response(
            {'error': 'Failed to fetch veterinarians.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_partner_hospitals(request):
    """
    Get list of partner hospitals
    
    GET /api/partner-hospitals/
    """
    try:
        queryset = PartnerHospital.objects.filter(is_active=True)
        serializer = PartnerHospitalSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching partner hospitals: {str(e)}")
        return Response(
            {'error': 'Failed to fetch partner hospitals.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_dashboard_data(request):
    """
    Get dashboard data for hospital management
    
    GET /api/dashboard/
    """
    try:
        # Get current metrics
        active_emergencies = EmergencyRequest.objects.filter(
            status__in=['pending', 'analyzed', 'assigned', 'in_progress']
        ).count()
        
        available_vets = Veterinarian.objects.filter(
            status='available',
            current_case__isnull=True
        ).count()
        
        # Calculate average wait time
        avg_wait_time = EmergencyRequest.objects.filter(
            estimated_wait_time__isnull=False
        ).aggregate(avg_wait=Avg('estimated_wait_time'))['avg_wait'] or 0
        
        partner_hospitals_count = PartnerHospital.objects.filter(is_active=True).count()
        
        # Get current cases (last 10)
        current_cases = EmergencyRequest.objects.filter(
            status__in=['pending', 'analyzed', 'assigned', 'in_progress']
        ).order_by('-created_at')[:10]
        
        # Get all veterinarians
        veterinarians = Veterinarian.objects.all()
        
        # Get partner hospitals
        partner_hospitals = PartnerHospital.objects.filter(is_active=True)
        
        # Get recent AI decisions (last 10)
        ai_decisions = AIDecision.objects.all().order_by('-created_at')[:10]
        
        # Get recent metrics (last 7 days)
        recent_metrics = SystemMetrics.objects.all().order_by('-date')[:7]
        
        dashboard_data = {
            'active_emergencies': active_emergencies,
            'available_vets': available_vets,
            'avg_wait_time': round(avg_wait_time, 1),
            'partner_hospitals': partner_hospitals_count,
            'current_cases': current_cases,
            'veterinarians': veterinarians,
            'partner_hospitals_list': partner_hospitals,
            'ai_decisions': ai_decisions,
            'recent_metrics': recent_metrics
        }
        
        serializer = DashboardDataSerializer(dashboard_data)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching dashboard data: {str(e)}")
        return Response(
            {'error': 'Failed to fetch dashboard data.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([AllowAny])
def update_emergency_status(request, request_id):
    """
    Update emergency request status
    
    POST /api/emergency-requests/{id}/update-status/
    """
    try:
        emergency_request = get_object_or_404(EmergencyRequest, id=request_id)
        new_status = request.data.get('status')
        
        if not new_status:
            return Response(
                {'error': 'Status is required.'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update status
        emergency_request.status = new_status
        
        if new_status == 'completed':
            emergency_request.completed_at = timezone.now()
            # Free up the assigned veterinarian
            if emergency_request.assigned_veterinarian:
                emergency_request.assigned_veterinarian.current_case = None
                emergency_request.assigned_veterinarian.status = 'available'
                emergency_request.assigned_veterinarian.save()
        
        emergency_request.save()
        
        serializer = EmergencyRequestSerializer(emergency_request)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error updating emergency status: {str(e)}")
        return Response(
            {'error': 'Failed to update status.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_ai_decisions(request):
    """
    Get recent AI decisions
    
    GET /api/ai-decisions/
    """
    try:
        limit = int(request.GET.get('limit', 20))
        decision_type = request.GET.get('type')
        
        queryset = AIDecision.objects.all()
        
        if decision_type:
            queryset = queryset.filter(decision_type=decision_type)
        
        queryset = queryset.order_by('-created_at')[:limit]
        
        serializer = AIDecisionSerializer(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching AI decisions: {str(e)}")
        return Response(
            {'error': 'Failed to fetch AI decisions.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['GET'])
@permission_classes([AllowAny])
def get_system_metrics(request):
    """
    Get system performance metrics
    
    GET /api/metrics/
    """
    try:
        days = int(request.GET.get('days', 30))
        start_date = timezone.now().date() - timedelta(days=days)
        
        queryset = SystemMetrics.objects.filter(date__gte=start_date)
        serializer = SystemMetricsSerializer(queryset, many=True)
        
        return Response(serializer.data, status=status.HTTP_200_OK)
        
    except Exception as e:
        logger.error(f"Error fetching system metrics: {str(e)}")
        return Response(
            {'error': 'Failed to fetch system metrics.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view(['POST'])
@permission_classes([AllowAny])
def create_system_metrics(request):
    """
    Create or update system metrics for a specific date
    
    POST /api/metrics/
    """
    try:
        serializer = SystemMetricsSerializer(data=request.data)
        if serializer.is_valid():
            # Check if metrics for this date already exist
            date = serializer.validated_data['date']
            existing_metrics = SystemMetrics.objects.filter(date=date).first()
            
            if existing_metrics:
                # Update existing metrics
                for field, value in serializer.validated_data.items():
                    if field != 'date':
                        setattr(existing_metrics, field, value)
                existing_metrics.save()
                return Response(SystemMetricsSerializer(existing_metrics).data, status=status.HTTP_200_OK)
            else:
                # Create new metrics
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
    except Exception as e:
        logger.error(f"Error creating system metrics: {str(e)}")
        return Response(
            {'error': 'Failed to create system metrics.'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
