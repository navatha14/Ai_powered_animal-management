"""
Django management command to populate the database with sample data
"""

from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from hospital.models import Veterinarian, PartnerHospital, EmergencyRequest, SystemMetrics
import random
from datetime import datetime, timedelta


class Command(BaseCommand):
    help = 'Populate the database with sample data for testing'

    def handle(self, *args, **options):
        self.stdout.write('Starting to populate sample data...')
        
        # Create sample users and veterinarians
        self.create_veterinarians()
        
        # Create partner hospitals
        self.create_partner_hospitals()
        
        # Create sample emergency requests
        self.create_emergency_requests()
        
        # Create system metrics
        self.create_system_metrics()
        
        self.stdout.write(
            self.style.SUCCESS('Successfully populated sample data!')
        )

    def create_veterinarians(self):
        """Create sample veterinarians"""
        self.stdout.write('Creating veterinarians...')
        
        veterinarians_data = [
            {
                'username': 'dr_smith',
                'first_name': 'Sarah',
                'last_name': 'Smith',
                'email': 'sarah.smith@vetcare.com',
                'license_number': 'VET001',
                'specialty': 'emergency',
                'experience_years': 8,
                'phone_number': '+1-555-0101',
                'status': 'available'
            },
            {
                'username': 'dr_johnson',
                'first_name': 'Michael',
                'last_name': 'Johnson',
                'email': 'michael.johnson@vetcare.com',
                'license_number': 'VET002',
                'specialty': 'surgery',
                'experience_years': 12,
                'phone_number': '+1-555-0102',
                'status': 'available'
            },
            {
                'username': 'dr_williams',
                'first_name': 'Emily',
                'last_name': 'Williams',
                'email': 'emily.williams@vetcare.com',
                'license_number': 'VET003',
                'specialty': 'internal',
                'experience_years': 6,
                'phone_number': '+1-555-0103',
                'status': 'available'
            },
            {
                'username': 'dr_brown',
                'first_name': 'David',
                'last_name': 'Brown',
                'email': 'david.brown@vetcare.com',
                'license_number': 'VET004',
                'specialty': 'cardiology',
                'experience_years': 15,
                'phone_number': '+1-555-0104',
                'status': 'on_break'
            },
            {
                'username': 'dr_davis',
                'first_name': 'Lisa',
                'last_name': 'Davis',
                'email': 'lisa.davis@vetcare.com',
                'license_number': 'VET005',
                'specialty': 'general',
                'experience_years': 5,
                'phone_number': '+1-555-0105',
                'status': 'available'
            }
        ]
        
        for vet_data in veterinarians_data:
            user, created = User.objects.get_or_create(
                username=vet_data['username'],
                defaults={
                    'first_name': vet_data['first_name'],
                    'last_name': vet_data['last_name'],
                    'email': vet_data['email'],
                    'is_staff': True,
                    'is_active': True
                }
            )
            
            if created:
                user.set_password('password123')
                user.save()
            
            Veterinarian.objects.get_or_create(
                user=user,
                defaults={
                    'license_number': vet_data['license_number'],
                    'specialty': vet_data['specialty'],
                    'experience_years': vet_data['experience_years'],
                    'phone_number': vet_data['phone_number'],
                    'status': vet_data['status']
                }
            )
        
        self.stdout.write(f'Created {len(veterinarians_data)} veterinarians')

    def create_partner_hospitals(self):
        """Create sample partner hospitals"""
        self.stdout.write('Creating partner hospitals...')
        
        hospitals_data = [
            {
                'name': 'City Animal Hospital',
                'address': '123 Main Street, City Center, State 12345',
                'phone_number': '+1-555-2001',
                'email': 'info@cityanimalhospital.com',
                'distance_miles': 2.3,
                'available_vets': 3,
                'wait_time_minutes': 10,
                'specialties': ['emergency', 'surgery', 'general']
            },
            {
                'name': 'Pet Emergency Center',
                'address': '456 Oak Avenue, Downtown, State 12345',
                'phone_number': '+1-555-2002',
                'email': 'emergency@petemergency.com',
                'distance_miles': 4.1,
                'available_vets': 2,
                'wait_time_minutes': 20,
                'specialties': ['emergency', 'cardiology', 'neurology']
            },
            {
                'name': '24/7 Vet Clinic',
                'address': '789 Pine Street, Suburb, State 12345',
                'phone_number': '+1-555-2003',
                'email': 'contact@24sevenvet.com',
                'distance_miles': 5.7,
                'available_vets': 1,
                'wait_time_minutes': 30,
                'specialties': ['emergency', 'general']
            }
        ]
        
        for hospital_data in hospitals_data:
            PartnerHospital.objects.get_or_create(
                name=hospital_data['name'],
                defaults=hospital_data
            )
        
        self.stdout.write(f'Created {len(hospitals_data)} partner hospitals')

    def create_emergency_requests(self):
        """Create sample emergency requests"""
        self.stdout.write('Creating emergency requests...')
        
        sample_requests = [
            {
                'pet_name': 'Buddy',
                'pet_type': 'dog',
                'pet_age': 5,
                'owner_name': 'John Smith',
                'phone_number': '+1-555-3001',
                'symptoms': 'Difficulty breathing, pale gums, lethargy',
                'urgency': 'critical',
                'status': 'assigned'
            },
            {
                'pet_name': 'Whiskers',
                'pet_type': 'cat',
                'pet_age': 3,
                'owner_name': 'Jane Doe',
                'phone_number': '+1-555-3002',
                'symptoms': 'Vomiting, not eating, hiding under bed',
                'urgency': 'urgent',
                'status': 'analyzed'
            },
            {
                'pet_name': 'Charlie',
                'pet_type': 'dog',
                'pet_age': 7,
                'owner_name': 'Bob Johnson',
                'phone_number': '+1-555-3003',
                'symptoms': 'Limping on front leg, swelling',
                'urgency': 'moderate',
                'status': 'pending'
            },
            {
                'pet_name': 'Luna',
                'pet_type': 'cat',
                'pet_age': 2,
                'owner_name': 'Alice Brown',
                'phone_number': '+1-555-3004',
                'symptoms': 'Itchy skin, hair loss, scratching constantly',
                'urgency': 'routine',
                'status': 'completed'
            },
            {
                'pet_name': 'Max',
                'pet_type': 'dog',
                'pet_age': 4,
                'owner_name': 'Tom Wilson',
                'phone_number': '+1-555-3005',
                'symptoms': 'Seizure, disorientation, drooling',
                'urgency': 'critical',
                'status': 'in_progress'
            }
        ]
        
        veterinarians = list(Veterinarian.objects.all())
        partner_hospitals = list(PartnerHospital.objects.all())
        
        for i, request_data in enumerate(sample_requests):
            # Create emergency request
            emergency_request = EmergencyRequest.objects.create(
                pet_name=request_data['pet_name'],
                pet_type=request_data['pet_type'],
                pet_age=request_data['pet_age'],
                owner_name=request_data['owner_name'],
                phone_number=request_data['phone_number'],
                symptoms=request_data['symptoms'],
                urgency=request_data['urgency'],
                status=request_data['status'],
                possible_conditions=self.get_sample_conditions(request_data['symptoms']),
                confidence_score=random.uniform(75.0, 95.0),
                ai_recommendations=self.get_sample_recommendations(request_data['urgency']),
                estimated_wait_time=self.get_estimated_wait_time(request_data['urgency']),
                created_at=timezone.now() - timedelta(hours=random.randint(1, 48))
            )
            
            # Assign veterinarian or partner hospital
            if request_data['status'] in ['assigned', 'in_progress']:
                if veterinarians and random.choice([True, False]):
                    vet = random.choice(veterinarians)
                    emergency_request.assigned_veterinarian = vet
                    emergency_request.assigned_at = timezone.now()
                elif partner_hospitals:
                    hospital = random.choice(partner_hospitals)
                    emergency_request.partner_hospital = hospital
                    emergency_request.assigned_at = timezone.now()
            
            if request_data['status'] == 'completed':
                emergency_request.completed_at = timezone.now()
            
            emergency_request.save()
        
        self.stdout.write(f'Created {len(sample_requests)} emergency requests')

    def create_system_metrics(self):
        """Create sample system metrics"""
        self.stdout.write('Creating system metrics...')
        
        # Create metrics for the last 30 days
        for i in range(30):
            date = timezone.now().date() - timedelta(days=i)
            
            SystemMetrics.objects.get_or_create(
                date=date,
                defaults={
                    'total_requests': random.randint(5, 25),
                    'successful_assignments': random.randint(4, 22),
                    'ai_accuracy': random.uniform(80.0, 95.0),
                    'avg_response_time': random.uniform(2.0, 8.0),
                    'avg_wait_time': random.uniform(10.0, 45.0),
                    'partner_hospital_usage': random.randint(0, 5)
                }
            )
        
        self.stdout.write('Created 30 days of system metrics')

    def get_sample_conditions(self, symptoms):
        """Get sample conditions based on symptoms"""
        conditions_map = {
            'breathing': ['Respiratory distress', 'Pneumonia', 'Allergic reaction'],
            'vomiting': ['Gastroenteritis', 'Food poisoning', 'Intestinal obstruction'],
            'limping': ['Fracture', 'Ligament tear', 'Arthritis'],
            'seizure': ['Seizure disorder', 'Head trauma', 'Toxic ingestion'],
            'itchy': ['Allergic dermatitis', 'Fungal infection', 'Parasitic infestation']
        }
        
        symptoms_lower = symptoms.lower()
        for keyword, conditions in conditions_map.items():
            if keyword in symptoms_lower:
                return conditions[:2]  # Return first 2 conditions
        
        return ['General examination needed', 'Symptom monitoring required']

    def get_sample_recommendations(self, urgency):
        """Get sample recommendations based on urgency"""
        recommendations_map = {
            'critical': [
                'Bring your pet to the emergency room immediately',
                'Keep your pet calm and comfortable',
                'Do not give food or water until examined',
                'Monitor breathing and heart rate closely'
            ],
            'urgent': [
                'Schedule an urgent appointment within 2-4 hours',
                'Keep your pet in a quiet, comfortable area',
                'Monitor symptoms closely',
                'Contact the clinic if symptoms worsen'
            ],
            'moderate': [
                'Schedule an appointment within 24 hours',
                'Monitor your pet\'s condition',
                'Keep a record of symptoms',
                'Contact the clinic if symptoms persist'
            ],
            'routine': [
                'Schedule a routine appointment',
                'Monitor your pet\'s condition',
                'Keep a record of symptoms',
                'Contact the clinic if symptoms worsen'
            ]
        }
        
        return recommendations_map.get(urgency, recommendations_map['moderate'])

    def get_estimated_wait_time(self, urgency):
        """Get estimated wait time based on urgency"""
        wait_times = {
            'critical': 5,
            'urgent': 15,
            'moderate': 60,
            'routine': 120
        }
        return wait_times.get(urgency, 60)
