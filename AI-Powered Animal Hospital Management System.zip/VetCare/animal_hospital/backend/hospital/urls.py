"""
URL configuration for hospital app
"""

from django.urls import path
from . import views

urlpatterns = [
    # Symptom Analysis
    path('analyze-symptoms/', views.analyze_symptoms, name='analyze_symptoms'),
    
    # Emergency Requests
    path('emergency-requests/', views.create_emergency_request, name='create_emergency_request'),
    path('emergency-requests/list/', views.get_emergency_requests, name='get_emergency_requests'),
    path('emergency-requests/<uuid:request_id>/', views.get_emergency_request, name='get_emergency_request'),
    path('emergency-requests/<uuid:request_id>/update-status/', views.update_emergency_status, name='update_emergency_status'),
    
    # Veterinarians
    path('veterinarians/', views.get_veterinarians, name='get_veterinarians'),
    
    # Partner Hospitals
    path('partner-hospitals/', views.get_partner_hospitals, name='get_partner_hospitals'),
    
    # Dashboard
    path('dashboard/', views.get_dashboard_data, name='get_dashboard_data'),
    
    # AI Decisions
    path('ai-decisions/', views.get_ai_decisions, name='get_ai_decisions'),
    
    # System Metrics
    path('metrics/', views.get_system_metrics, name='get_system_metrics'),
    path('metrics/create/', views.create_system_metrics, name='create_system_metrics'),
]
