"""
AI Service for Animal Hospital Management System

This module handles:
- Symptom analysis using NLP
- Veterinarian assignment based on AI recommendations
- Partner hospital routing
- Machine learning pattern recognition
"""

import json
import time
import logging
from typing import Dict, List, Tuple, Optional
from django.conf import settings
from django.utils import timezone
from .models import Veterinarian, PartnerHospital, EmergencyRequest, AIDecision, SymptomPattern

logger = logging.getLogger(__name__)


class AIService:
    """Main AI service class for handling all AI operations"""
    
    def __init__(self):
        self.openai_api_key = settings.OPENAI_API_KEY
        self.model = settings.AI_MODEL
        
        # Symptom keywords for different conditions
        self.symptom_keywords = {
            'respiratory': ['breathing', 'cough', 'wheeze', 'panting', 'gasping', 'sneezing', 'nasal discharge'],
            'cardiac': ['heart', 'pulse', 'pale gums', 'weakness', 'collapse', 'fainting'],
            'gastrointestinal': ['vomit', 'diarrhea', 'not eating', 'abdominal pain', 'bloating', 'constipation'],
            'neurological': ['seizure', 'tremor', 'disorientation', 'head tilt', 'circling', 'paralysis'],
            'dermatological': ['itchy', 'rash', 'hair loss', 'sores', 'lumps', 'swelling'],
            'orthopedic': ['limping', 'lameness', 'swelling', 'fracture', 'joint pain'],
            'emergency': ['bleeding', 'unconscious', 'severe pain', 'difficulty breathing', 'trauma']
        }
        
        # Condition severity mapping
        self.urgency_mapping = {
            'emergency': 'critical',
            'respiratory': 'urgent',
            'cardiac': 'urgent',
            'neurological': 'urgent',
            'gastrointestinal': 'moderate',
            'dermatological': 'routine',
            'orthopedic': 'moderate'
        }
    
    def analyze_symptoms(self, symptoms: str, pet_type: str, urgency_level: str, pet_age: Optional[int] = None) -> Dict:
        """
        Analyze pet symptoms using AI and return possible conditions and recommendations
        
        Args:
            symptoms: Description of pet's symptoms
            pet_type: Type of pet (dog, cat, etc.)
            urgency_level: Urgency level from user input
            pet_age: Age of the pet (optional)
        
        Returns:
            Dictionary containing analysis results
        """
        start_time = time.time()
        
        try:
            # Use OpenAI for advanced analysis if API key is available
            if self.openai_api_key:
                analysis_result = self._analyze_with_openai(symptoms, pet_type, urgency_level, pet_age)
            else:
                # Fallback to rule-based analysis
                analysis_result = self._analyze_with_rules(symptoms, pet_type, urgency_level, pet_age)
            
            processing_time = time.time() - start_time
            
            # Log the AI decision
            self._log_ai_decision(
                decision_type='symptom_analysis',
                input_data={
                    'symptoms': symptoms,
                    'pet_type': pet_type,
                    'urgency_level': urgency_level,
                    'pet_age': pet_age
                },
                output_data=analysis_result,
                confidence_score=analysis_result.get('confidence_score', 0.0),
                processing_time=processing_time
            )
            
            return analysis_result
            
        except Exception as e:
            logger.error(f"Error in symptom analysis: {str(e)}")
            # Return fallback analysis
            return self._get_fallback_analysis(symptoms, pet_type, urgency_level)
    
    def _analyze_with_openai(self, symptoms: str, pet_type: str, urgency_level: str, pet_age: Optional[int] = None) -> Dict:
        """Analyze symptoms using OpenAI API"""
        try:
            import openai
            
            openai.api_key = self.openai_api_key
            
            prompt = self._build_analysis_prompt(symptoms, pet_type, urgency_level, pet_age)
            
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are an expert veterinary AI assistant. Analyze pet symptoms and provide medical recommendations."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.3
            )
            
            analysis_text = response.choices[0].message.content
            return self._parse_openai_response(analysis_text, symptoms, pet_type, urgency_level)
            
        except Exception as e:
            logger.error(f"OpenAI API error: {str(e)}")
            return self._analyze_with_rules(symptoms, pet_type, urgency_level, pet_age)
    
    def _analyze_with_rules(self, symptoms: str, pet_type: str, urgency_level: str, pet_age: Optional[int] = None) -> Dict:
        """Fallback rule-based analysis"""
        symptoms_lower = symptoms.lower()
        
        # Identify possible conditions based on keywords
        possible_conditions = []
        detected_categories = []
        
        for category, keywords in self.symptom_keywords.items():
            if any(keyword in symptoms_lower for keyword in keywords):
                detected_categories.append(category)
                possible_conditions.extend(self._get_conditions_for_category(category, pet_type))
        
        # Remove duplicates
        possible_conditions = list(set(possible_conditions))
        
        # Determine urgency based on detected categories
        ai_urgency = self._determine_urgency(detected_categories, urgency_level)
        
        # Get recommended specialty
        recommended_specialty = self._get_recommended_specialty(detected_categories)
        
        # Calculate confidence score
        confidence_score = self._calculate_confidence_score(detected_categories, symptoms)
        
        return {
            'possible_conditions': possible_conditions[:5],  # Top 5 conditions
            'confidence_score': confidence_score,
            'recommended_vet_specialty': recommended_specialty,
            'urgency_assessment': ai_urgency,
            'next_steps': self._get_next_steps(ai_urgency, detected_categories),
            'estimated_wait_time': self._estimate_wait_time(ai_urgency)
        }
    
    def _build_analysis_prompt(self, symptoms: str, pet_type: str, urgency_level: str, pet_age: Optional[int] = None) -> str:
        """Build prompt for OpenAI analysis"""
        age_info = f" (Age: {pet_age} years)" if pet_age else ""
        
        return f"""
        Analyze the following pet symptoms and provide a veterinary assessment:
        
        Pet: {pet_type}{age_info}
        Symptoms: {symptoms}
        Owner-reported urgency: {urgency_level}
        
        Please provide:
        1. Top 3-5 possible medical conditions
        2. Recommended veterinarian specialty
        3. Urgency assessment (critical/urgent/moderate/routine)
        4. Next steps for the owner
        5. Confidence score (0-100)
        
        Format your response as JSON with these keys:
        - possible_conditions: list of conditions
        - recommended_specialty: string
        - urgency_assessment: string
        - next_steps: list of strings
        - confidence_score: number
        """
    
    def _parse_openai_response(self, response_text: str, symptoms: str, pet_type: str, urgency_level: str) -> Dict:
        """Parse OpenAI response and extract structured data"""
        try:
            # Try to extract JSON from response
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                analysis_data = json.loads(json_match.group())
            else:
                # Fallback to text parsing
                analysis_data = self._parse_text_response(response_text)
            
            # Add estimated wait time
            analysis_data['estimated_wait_time'] = self._estimate_wait_time(
                analysis_data.get('urgency_assessment', urgency_level)
            )
            
            return analysis_data
            
        except Exception as e:
            logger.error(f"Error parsing OpenAI response: {str(e)}")
            return self._analyze_with_rules(symptoms, pet_type, urgency_level)
    
    def _parse_text_response(self, response_text: str) -> Dict:
        """Parse text response when JSON parsing fails"""
        # Simple text parsing as fallback
        lines = response_text.split('\n')
        analysis_data = {
            'possible_conditions': [],
            'recommended_specialty': 'general',
            'urgency_assessment': 'moderate',
            'next_steps': [],
            'confidence_score': 75.0
        }
        
        for line in lines:
            if 'condition' in line.lower():
                analysis_data['possible_conditions'].append(line.strip('- '))
            elif 'specialty' in line.lower():
                analysis_data['recommended_specialty'] = line.split(':')[-1].strip()
            elif 'urgency' in line.lower():
                analysis_data['urgency_assessment'] = line.split(':')[-1].strip().lower()
            elif 'step' in line.lower():
                analysis_data['next_steps'].append(line.strip('- '))
        
        return analysis_data
    
    def _get_conditions_for_category(self, category: str, pet_type: str) -> List[str]:
        """Get specific conditions for a symptom category"""
        conditions_map = {
            'respiratory': [
                'Upper respiratory infection',
                'Pneumonia',
                'Asthma',
                'Allergic reaction',
                'Foreign body obstruction'
            ],
            'cardiac': [
                'Heart disease',
                'Cardiac arrhythmia',
                'Heart failure',
                'Shock',
                'Anemia'
            ],
            'gastrointestinal': [
                'Gastroenteritis',
                'Food poisoning',
                'Intestinal obstruction',
                'Pancreatitis',
                'Inflammatory bowel disease'
            ],
            'neurological': [
                'Seizure disorder',
                'Head trauma',
                'Stroke',
                'Vestibular disease',
                'Brain tumor'
            ],
            'dermatological': [
                'Allergic dermatitis',
                'Fungal infection',
                'Bacterial infection',
                'Parasitic infestation',
                'Autoimmune disease'
            ],
            'orthopedic': [
                'Fracture',
                'Ligament tear',
                'Arthritis',
                'Hip dysplasia',
                'Spinal injury'
            ],
            'emergency': [
                'Trauma',
                'Severe bleeding',
                'Shock',
                'Toxic ingestion',
                'Heat stroke'
            ]
        }
        
        return conditions_map.get(category, [])
    
    def _determine_urgency(self, categories: List[str], user_urgency: str) -> str:
        """Determine urgency level based on detected categories"""
        if 'emergency' in categories:
            return 'critical'
        
        # Check if any category suggests urgent care
        urgent_categories = ['respiratory', 'cardiac', 'neurological']
        if any(cat in categories for cat in urgent_categories):
            return 'urgent'
        
        # Default to user's assessment or moderate
        urgency_mapping = {
            'critical': 'critical',
            'urgent': 'urgent',
            'moderate': 'moderate',
            'routine': 'routine'
        }
        
        return urgency_mapping.get(user_urgency.lower(), 'moderate')
    
    def _get_recommended_specialty(self, categories: List[str]) -> str:
        """Get recommended veterinarian specialty based on detected categories"""
        specialty_mapping = {
            'emergency': 'emergency',
            'cardiac': 'cardiology',
            'neurological': 'neurology',
            'orthopedic': 'orthopedics',
            'dermatological': 'dermatology'
        }
        
        for category in categories:
            if category in specialty_mapping:
                return specialty_mapping[category]
        
        return 'general'
    
    def _calculate_confidence_score(self, categories: List[str], symptoms: str) -> float:
        """Calculate confidence score for the analysis"""
        base_score = 60.0
        
        # Increase confidence based on number of matching categories
        category_bonus = len(categories) * 10
        
        # Increase confidence based on symptom detail
        detail_bonus = min(len(symptoms.split()) * 2, 20)
        
        total_score = base_score + category_bonus + detail_bonus
        return min(total_score, 100.0)
    
    def _get_next_steps(self, urgency: str, categories: List[str]) -> List[str]:
        """Get recommended next steps based on urgency and categories"""
        if urgency == 'critical':
            return [
                'Bring your pet to the emergency room immediately',
                'Keep your pet calm and comfortable',
                'Do not give food or water until examined',
                'Monitor breathing and heart rate closely'
            ]
        elif urgency == 'urgent':
            return [
                'Schedule an urgent appointment within 2-4 hours',
                'Keep your pet in a quiet, comfortable area',
                'Monitor symptoms closely',
                'Contact the clinic if symptoms worsen'
            ]
        else:
            return [
                'Schedule a routine appointment',
                'Monitor your pet\'s condition',
                'Keep a record of symptoms',
                'Contact the clinic if symptoms persist or worsen'
            ]
    
    def _estimate_wait_time(self, urgency: str) -> int:
        """Estimate wait time in minutes based on urgency"""
        wait_times = {
            'critical': 5,
            'urgent': 15,
            'moderate': 60,
            'routine': 120
        }
        return wait_times.get(urgency.lower(), 60)
    
    def _get_fallback_analysis(self, symptoms: str, pet_type: str, urgency_level: str) -> Dict:
        """Fallback analysis when AI services fail"""
        return {
            'possible_conditions': ['General examination needed'],
            'confidence_score': 50.0,
            'recommended_vet_specialty': 'general',
            'urgency_assessment': urgency_level,
            'next_steps': [
                'Schedule an appointment for examination',
                'Monitor your pet\'s condition',
                'Contact the clinic if symptoms worsen'
            ],
            'estimated_wait_time': 60
        }
    
    def assign_veterinarian(self, emergency_request: EmergencyRequest) -> Optional[Veterinarian]:
        """
        Assign the most suitable veterinarian for an emergency request
        
        Args:
            emergency_request: The emergency request to assign
        
        Returns:
            Assigned Veterinarian or None if no suitable vet available
        """
        try:
            # Get available veterinarians
            available_vets = Veterinarian.objects.filter(
                status='available',
                current_case__isnull=True
            )
            
            if not available_vets.exists():
                return None
            
            # Find best match based on specialty and experience
            recommended_specialty = emergency_request.possible_conditions[0] if emergency_request.possible_conditions else 'general'
            
            # Try to find vet with matching specialty
            specialty_vets = available_vets.filter(specialty=recommended_specialty)
            if specialty_vets.exists():
                return specialty_vets.order_by('-experience_years').first()
            
            # Fallback to general practice vets
            general_vets = available_vets.filter(specialty='general')
            if general_vets.exists():
                return general_vets.order_by('-experience_years').first()
            
            # Return any available vet
            return available_vets.first()
            
        except Exception as e:
            logger.error(f"Error assigning veterinarian: {str(e)}")
            return None
    
    def find_partner_hospital(self, emergency_request: EmergencyRequest) -> Optional[PartnerHospital]:
        """
        Find suitable partner hospital if no local vets available
        
        Args:
            emergency_request: The emergency request to route
        
        Returns:
            Suitable PartnerHospital or None
        """
        try:
            # Get active partner hospitals
            partner_hospitals = PartnerHospital.objects.filter(
                is_active=True,
                available_vets__gt=0
            ).order_by('distance_miles')
            
            if not partner_hospitals.exists():
                return None
            
            # Find hospital with matching specialty if possible
            recommended_specialty = emergency_request.possible_conditions[0] if emergency_request.possible_conditions else 'general'
            
            for hospital in partner_hospitals:
                if recommended_specialty in hospital.specialties:
                    return hospital
            
            # Return closest hospital
            return partner_hospitals.first()
            
        except Exception as e:
            logger.error(f"Error finding partner hospital: {str(e)}")
            return None
    
    def _log_ai_decision(self, decision_type: str, input_data: Dict, output_data: Dict, 
                        confidence_score: float, processing_time: float, emergency_request: EmergencyRequest = None):
        """Log AI decision for tracking and improvement"""
        try:
            AIDecision.objects.create(
                emergency_request=emergency_request,
                decision_type=decision_type,
                input_data=input_data,
                output_data=output_data,
                confidence_score=confidence_score,
                processing_time=processing_time
            )
        except Exception as e:
            logger.error(f"Error logging AI decision: {str(e)}")


# Global AI service instance
ai_service = AIService()
