#!/usr/bin/env python3
"""
Setup script for AI-Powered Animal Hospital Management System
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def run_command(command, cwd=None):
    """Run a command and return the result"""
    try:
        result = subprocess.run(
            command, 
            shell=True, 
            cwd=cwd, 
            capture_output=True, 
            text=True, 
            check=True
        )
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"Current version: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version.split()[0]}")
    return True

def check_pip():
    """Check if pip is available"""
    success, _ = run_command("pip --version")
    if not success:
        print("❌ pip is not available")
        return False
    print("✅ pip is available")
    return True

def create_virtual_environment():
    """Create virtual environment"""
    print("\n📦 Creating virtual environment...")
    
    venv_path = Path("backend/venv")
    if venv_path.exists():
        print("✅ Virtual environment already exists")
        return True
    
    success, output = run_command("python -m venv venv", cwd="backend")
    if not success:
        print(f"❌ Failed to create virtual environment: {output}")
        return False
    
    print("✅ Virtual environment created")
    return True

def get_activation_command():
    """Get the command to activate virtual environment based on OS"""
    if platform.system() == "Windows":
        return "backend\\venv\\Scripts\\activate"
    else:
        return "source backend/venv/bin/activate"

def install_dependencies():
    """Install Python dependencies"""
    print("\n📚 Installing dependencies...")
    
    # Determine pip command based on OS
    if platform.system() == "Windows":
        pip_cmd = "backend\\venv\\Scripts\\pip"
    else:
        pip_cmd = "backend/venv/bin/pip"
    
    success, output = run_command(f"{pip_cmd} install -r requirements.txt", cwd="backend")
    if not success:
        print(f"❌ Failed to install dependencies: {output}")
        return False
    
    print("✅ Dependencies installed")
    return True

def setup_database():
    """Set up Django database"""
    print("\n🗄️ Setting up database...")
    
    # Determine python command based on OS
    if platform.system() == "Windows":
        python_cmd = "backend\\venv\\Scripts\\python"
    else:
        python_cmd = "backend/venv/bin/python"
    
    # Run migrations
    success, output = run_command(f"{python_cmd} manage.py migrate", cwd="backend")
    if not success:
        print(f"❌ Failed to run migrations: {output}")
        return False
    
    print("✅ Database migrations completed")
    return True

def populate_sample_data():
    """Populate database with sample data"""
    print("\n🌱 Populating sample data...")
    
    # Determine python command based on OS
    if platform.system() == "Windows":
        python_cmd = "backend\\venv\\Scripts\\python"
    else:
        python_cmd = "backend/venv/bin/python"
    
    success, output = run_command(f"{python_cmd} manage.py populate_sample_data", cwd="backend")
    if not success:
        print(f"❌ Failed to populate sample data: {output}")
        return False
    
    print("✅ Sample data populated")
    return True

def create_env_file():
    """Create .env file with default settings"""
    print("\n⚙️ Creating environment file...")
    
    env_path = Path("backend/.env")
    if env_path.exists():
        print("✅ .env file already exists")
        return True
    
    env_content = """# Django Settings
SECRET_KEY=django-insecure-change-this-in-production
DEBUG=True

# Database (for production)
DB_NAME=animal_hospital
DB_USER=postgres
DB_PASSWORD=your-password
DB_HOST=localhost
DB_PORT=5432

# AI Services (optional)
OPENAI_API_KEY=your-openai-api-key

# Celery (for background tasks)
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0
"""
    
    try:
        with open(env_path, 'w') as f:
            f.write(env_content)
        print("✅ .env file created")
        return True
    except Exception as e:
        print(f"❌ Failed to create .env file: {e}")
        return False

def main():
    """Main setup function"""
    print("🏥 AI-Powered Animal Hospital Management System Setup")
    print("=" * 60)
    
    # Check prerequisites
    if not check_python_version():
        sys.exit(1)
    
    if not check_pip():
        sys.exit(1)
    
    # Create virtual environment
    if not create_virtual_environment():
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        sys.exit(1)
    
    # Create .env file
    if not create_env_file():
        sys.exit(1)
    
    # Setup database
    if not setup_database():
        sys.exit(1)
    
    # Populate sample data
    if not populate_sample_data():
        sys.exit(1)
    
    print("\n🎉 Setup completed successfully!")
    print("\nNext steps:")
    print("1. Start the Django server:")
    if platform.system() == "Windows":
        print("   cd backend")
        print("   venv\\Scripts\\activate")
        print("   python manage.py runserver")
    else:
        print("   cd backend")
        print("   source venv/bin/activate")
        print("   python manage.py runserver")
    
    print("\n2. Open the frontend:")
    print("   Open frontend/index.html in your web browser")
    
    print("\n3. Access the admin interface:")
    print("   http://localhost:8000/admin/")
    print("   (Create a superuser with: python manage.py createsuperuser)")
    
    print("\n4. API endpoints:")
    print("   http://localhost:8000/api/")
    
    print("\n📚 For more information, see README.md")

if __name__ == "__main__":
    main()
